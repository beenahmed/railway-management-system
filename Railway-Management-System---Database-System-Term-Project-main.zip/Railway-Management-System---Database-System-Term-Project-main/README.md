# TrainTrac-Railway-Management-System---Database-System-Term-Project


Hosting site used: 000webhost

Functionality of the website: 
•	View available train list
•	Search a train going from an inputted source to an inputted destination
•	Book a ticket
•	Cancel a booking
•	Check status of booked ticket-along with other details


What the webiste looks like:
![image](https://github.com/beenish01/Railway-Management-System---Database-System-Term-Project/assets/118468315/b79f6590-fdd5-4ed4-8e83-59504f4db5da)
![image](https://github.com/beenish01/Railway-Management-System---Database-System-Term-Project/assets/118468315/b545f00e-bf76-4e4a-bca0-9a973c2da6e4)
![image](https://github.com/beenish01/Railway-Management-System---Database-System-Term-Project/assets/118468315/04d76f67-0df7-4bf5-b101-259d2b48ddea)
![image](https://github.com/beenish01/Railway-Management-System---Database-System-Term-Project/assets/118468315/b2eaac9e-5918-46bf-9347-e8693dea19f2)
![image](https://github.com/beenish01/Railway-Management-System---Database-System-Term-Project/assets/118468315/6ba36877-c3f3-4537-8d4d-e47f365adfb4)
![image](https://github.com/beenish01/Railway-Management-System---Database-System-Term-Project/assets/118468315/34d36e0d-0198-4b2e-8b20-e71d4f750112)
![image](https://github.com/beenish01/Railway-Management-System---Database-System-Term-Project/assets/118468315/f63b8b93-a07f-4318-83f8-7b73bbd01561)
![image](https://github.com/beenish01/Railway-Management-System---Database-System-Term-Project/assets/118468315/6beb7d77-976f-4b12-90d5-78ffeff34cbc)


